<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Wishlist\\App\\Providers\\WishlistServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Wishlist\\App\\Providers\\WishlistServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
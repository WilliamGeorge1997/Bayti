<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Order\\App\\Providers\\OrderServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Order\\App\\Providers\\OrderServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
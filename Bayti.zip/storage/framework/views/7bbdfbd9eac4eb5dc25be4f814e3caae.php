## Laravel 10

- Use the ___SINGLE_BACKTICK___search-docs___SINGLE_BACKTICK___ tool to get version specific documentation.
- Middleware typically live in ___SINGLE_BACKTICK___app/Http/Middleware/___SINGLE_BACKTICK___ and service providers in ___SINGLE_BACKTICK___app/Providers/___SINGLE_BACKTICK___.
- There is no ___SINGLE_BACKTICK___bootstrap/app.php___SINGLE_BACKTICK___ application configuration in Laravel 10:
    - Middleware registration is in ___SINGLE_BACKTICK___app/Http/Kernel.php___SINGLE_BACKTICK___
    - Exception handling is in ___SINGLE_BACKTICK___app/Exceptions/Handler.php___SINGLE_BACKTICK___
    - Console commands and schedule registration is in ___SINGLE_BACKTICK___app/Console/Kernel.php___SINGLE_BACKTICK___
    - Rate limits likely exist in ___SINGLE_BACKTICK___RouteServiceProvider___SINGLE_BACKTICK___ or ___SINGLE_BACKTICK___app/Http/Kernel.php___SINGLE_BACKTICK___
- When using Eloquent model casts, you must use ___SINGLE_BACKTICK___protected $casts = [];___SINGLE_BACKTICK___ and not the ___SINGLE_BACKTICK___casts()___SINGLE_BACKTICK___ method. The ___SINGLE_BACKTICK___casts()___SINGLE_BACKTICK___ method isn't available on models in Laravel 10.
<?php /**PATH E:\Programming\Nanosoft\Bayti\storage\framework\views/c5ddfaa473e6d73a82f7973ceacd5b6d.blade.php ENDPATH**/ ?>
<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Notification\\App\\Providers\\NotificationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Notification\\App\\Providers\\NotificationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
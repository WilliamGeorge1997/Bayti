<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Property\\App\\Providers\\PropertyServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Property\\App\\Providers\\PropertyServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
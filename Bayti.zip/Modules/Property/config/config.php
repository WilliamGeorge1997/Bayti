<?php

return [
    'name' => 'Property',
];

@extends('common::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>Module: {!! config('common.name') !!}</p>
@endsection

<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Restaurant\\App\\Providers\\RestaurantServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Restaurant\\App\\Providers\\RestaurantServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);